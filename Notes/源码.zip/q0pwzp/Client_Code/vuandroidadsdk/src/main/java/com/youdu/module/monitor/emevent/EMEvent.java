package com.youdu.module.monitor.emevent;

/**
 * @author: vision
 * @function:
 * @date: 16/6/13
 */
public class EMEvent {

    public FullEvent full;
    public ExfuEvent exitFull;
    public PauseEvent pause;
}

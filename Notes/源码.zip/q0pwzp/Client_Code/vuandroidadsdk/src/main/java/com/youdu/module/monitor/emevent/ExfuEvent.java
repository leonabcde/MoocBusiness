package com.youdu.module.monitor.emevent;

import com.youdu.module.monitor.Monitor;

import java.util.ArrayList;

/**
 * @author: vision
 * @function:
 * @date: 16/6/13
 */
public class ExfuEvent {

    public ArrayList<Monitor> content;
}

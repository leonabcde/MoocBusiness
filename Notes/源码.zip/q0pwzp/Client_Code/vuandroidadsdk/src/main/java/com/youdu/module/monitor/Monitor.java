package com.youdu.module.monitor;

/**
 * @author: qndroid
 * @function:
 * @date: 16/6/13
 */
public class Monitor {

    public String ver;
    public String url;
    public int time;
}

package com.youdu.module.mina;

import com.youdu.module.BaseModel;

/**
 * Created by renzhiqiang on 16/8/20.
 */
public class MinaModel extends BaseModel {

    public int ecode;
    public String emsg;
    public MinaContent data;

}
